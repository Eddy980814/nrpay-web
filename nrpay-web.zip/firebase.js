// Your Firebase config here
const firebaseConfig = {
  apiKey: "AIzaSyBjA9Oln59AiplMoOMrW_tzNLfV8RFRojQ",
  authDomain: "nrpay-abbce.firebaseapp.com",
  projectId: "nrpay-abbce",
  storageBucket: "nrpay-abbce.firebasestorage.app",
  messagingSenderId: "342356133578",
  appId: "1:342356133578:web:86e13f16ae0a40be15d633"
};
firebase.initializeApp(firebaseConfig);
firebase.firestore();